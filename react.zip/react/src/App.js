import React from 'react';
import './App.css';
import Card from './Card';
function App() {
  const services = [
    {
      title: "Darjeeling",
      subtitle: "West Bengal",
      desc: "Surrounded by infinite slopes of emerald-green tea plantations and set against a backdrop of jagged white Himalayan peaks, Darjeeling is nestled away in the northern regions of West Bengal",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5_e5lZzN7DkfRnImDAwJ1aNLCy4O80GouJA&usqp=CAU",
    },
    {
      title: "Shillong",
      subtitle: "Meghalaya",
      desc: "The capital city of Meghalaya, Shillong sits amidst the Khasi Hills. One of the most charming hill stations of India, it’s famous for receiving the highest rainfall in the world and for its dynamic music scene.",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR935r8l4Y0wXslQQBDa-p5MqmAMMvcj0FjZw&usqp=CAU",
    },
    {
      title: "Coorg",
      subtitle: "Karnataka",
      desc : "Spread out on the Western Ghats, the misty valley of Coorg is enveloped in emerald landscapes and acres of coffee, tea and spice plantations. Fondly referred to as the ‘Scotland of India",
      image:
        "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQWWknd2IS1vWwK_4lOQP2ljBBJ2T_3j93kzw&usqp=CAU",
    },
    {
      title: "Ooty",
      subtitle: "Tamilnadu",
      desc:"Established as a summer retreat by the British and nicknamed ‘Snooty Ooty',Ooty is a visual delight filled with pretty cottages, fenced flower gardens, thatched-roof churches and terraced botanical gardens",
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRe_rkqOHmbMmT-GIhSrdnuwDggtNsFlt8t1w&usqp=CAU",
    },
    {
      title: "Coonoor",
      subtitle: "Tamilnadu",
      desc:"Smaller and quieter than its neighbour Ooty, Coonoor is nestled in the Nilgiri Mountains and is surrounded by rolling hills and tea and coffee plantations",
      
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSTA3XUxI2EXAatqGDJvK0nQsf9A2UOK9v1JQ&usqp=CAU",
    },
    {
      title: "Manali",
      subtitle: "Himachal Pradesh",
      desc: "With mountain adventures beckoning from all directions, Manali is one of the best hill stations in North India for those looking to unwind ",
      
      image: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQbDq2LhHUqmZpMrDVLuQsbcPiJu3ys5iJA2g&usqp=CAU",
    },
  ];

  return (
    <div className="App">
      <h1 className="title">Top Hill Stations In India </h1>
      <br />
      <br />
      <div className="container">
        {services.map((service, index) => (
          <Card
            key={index}
            title={service.title}
            subtitle={service.subtitle}
            desc={service.desc}
            image={service.image}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
